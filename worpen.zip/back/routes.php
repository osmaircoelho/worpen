<?php
// Folders
$FOLDERS['back'] = "back/";
$FOLDERS['language'] = "front/language/";
$FOLDERS['template'] = "front/template/";

// Path
$PATH['template'] = $FOLDERS['template']."/";
$PATH['language'] = $FOLDERS['language'].$INFO['language']."/";
$PATH['modstart'] = $INFO['modstart'];
$PATH['error'] = $PATH['template']."error.php";
# Folder BACK modules -> $PATH['module']
