<?php
$header_text = array(
  "all" => "All",
  "notif" => "Notifications",
  "no_notif" => "No Notifications :)",
  "admin" => "Administrator",
  "settings" => "Settings",
  "logoff" => "Logoff"
);

$search_text = array(
  "noresult" => "No results found!",
  "oneresult" => "1 result found!",
  "results" => "results found!"
);
