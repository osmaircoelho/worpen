<section>
  <div class="row">

    <h1>Welcome <?= $INFO_USER['fullname']; ?></h1>
    <p>This platform uses the Worpen, open source modular system, visit <a href="http://worpen.github.io/" target="_blank">http://worpen.github.io/</a></p>
  </div>
</section>