<section>
  <h1>Oops, Page not found <i class="fa fa-frown-o"></i></h1>
</section>