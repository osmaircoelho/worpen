<?php

  include "header.php";
  
  include $PAGE_CONTENT;
  
  include "footer.php";
