
    <footer>
      <?= worpen_footer(); ?>
    </footer>

    <script src="<?= $PATH['template']; ?>_files/js/jquery.min.js"></script>
    <script src="<?= $PATH['template']; ?>_files/js/bootstrap.min.js"></script>
  </body>
</html>
