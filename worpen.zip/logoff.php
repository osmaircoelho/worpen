<?php
session_start();

include 'back/functions.php';
worpen_logoff();
?>